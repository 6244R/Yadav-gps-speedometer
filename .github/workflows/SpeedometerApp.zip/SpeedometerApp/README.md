# 🏎️ GPS Speedometer - Android App

## APK Banane ke Steps (Android Studio)

### Step 1: Android Studio Download karo
👉 https://developer.android.com/studio
Install karo (free hai)

---

### Step 2: Project Open karo
1. Android Studio open karo
2. **"Open"** click karo
3. **SpeedometerApp** folder select karo
4. Gradle sync hone do (2-3 minute lagega)

---

### Step 3: Build > APK
1. Top menu mein **Build** click karo
2. **Build Bundle(s) / APK(s)** → **Build APK(s)**
3. Wait karo... 1-2 minute
4. Niche **"locate"** link aayega — click karo
5. APK mil jaayega: `app/build/outputs/apk/debug/app-debug.apk`

---

### Step 4: Phone mein Install karo
1. APK file WhatsApp/USB se phone pe bhejo
2. Phone Settings → **Unknown Sources** allow karo
   - Settings → Security → Unknown Apps → Allow
3. APK tap karo → Install

---

## ✅ App Features
- 🏎️ Real GPS speed (km/h) - native Android GPS
- 📍 Accurate distance tracking (haversine formula)
- 🔧 Service reminder with custom KM limit
- 📳 Vibration alert jab service due ho
- 🔔 Background notification (app band ho tab bhi GPS chalta hai)
- 💾 Data save rehta hai (localStorage)
- 🌙 Screen off nahi hogi jab app chal raha ho

## ⚠️ GPS Permission
App first time open karne par GPS permission maangega — **Allow** karo.

Android 10+ mein **"Allow all the time"** select karo background GPS ke liye.
