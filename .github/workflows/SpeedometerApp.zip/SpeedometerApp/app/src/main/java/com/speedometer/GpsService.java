package com.speedometer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class GpsService extends Service implements LocationListener {

    private static final String CHANNEL_ID   = "SpeedometerGPS";
    private static final int    NOTIF_ID     = 1;
    private LocationManager locationManager;
    private boolean running = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!running) {
            running = true;
            createNotificationChannel();
            startForeground(NOTIF_ID, buildNotification("GPS tracking chal raha hai...", 0));
            startGps();
        }

        return START_STICKY; // Restart if killed
    }

    private void startGps() {
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        try {
            // High accuracy GPS - update every 1 second or 5 meters
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                1000,   // 1 second
                2,      // 2 meters
                this
            );
            // Fallback: Network provider
            locationManager.requestLocationUpdates(
                LocationManager.NETWORK_PROVIDER,
                2000,
                5,
                this
            );
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        double speedKmh = 0;
        if (location.hasSpeed()) {
            speedKmh = location.getSpeed() * 3.6; // m/s -> km/h
        }

        // Update notification
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIF_ID, buildNotification(
            String.format("Speed: %.0f km/h", speedKmh), speedKmh
        ));

        // Broadcast to MainActivity
        Intent broadcast = new Intent("GPS_UPDATE");
        broadcast.putExtra("speed",    speedKmh);
        broadcast.putExtra("lat",      location.getLatitude());
        broadcast.putExtra("lon",      location.getLongitude());
        broadcast.putExtra("accuracy", (double) location.getAccuracy());
        LocalBroadcastManager.getInstance(this).sendBroadcast(broadcast);
    }

    private Notification buildNotification(String text, double speed) {
        Intent notifIntent = new Intent(this, MainActivity.class);
        notifIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, notifIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🏎️ GPS Speedometer")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(pi)
            .setOngoing(true)       // Can't be dismissed
            .setSilent(true)
            .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "GPS Speedometer",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Background GPS tracking");
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        if (locationManager != null) {
            locationManager.removeUpdates(this);
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onStatusChanged(String p, int s, Bundle e) {}
    @Override public void onProviderEnabled(String p) {}
    @Override public void onProviderDisabled(String p) {}
}
